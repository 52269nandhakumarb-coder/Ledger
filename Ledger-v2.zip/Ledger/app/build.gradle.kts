plugins { id("com.android.application"); id("org.jetbrains.kotlin.android") }
android {
    namespace = "com.example.ledger"
    compileSdk = 34
    defaultConfig { applicationId = "com.example.ledger"; minSdk = 26; targetSdk = 34; versionCode = 1; versionName = "1.0" }
    signingConfigs { create("fixed") { storeFile = file("ledger.keystore"); storePassword = "ledger123"; keyAlias = "ledger"; keyPassword = "ledger123" } }
    buildTypes { getByName("debug") { signingConfig = signingConfigs.getByName("fixed") } }
    buildFeatures { compose = true }
    composeOptions { kotlinCompilerExtensionVersion = "1.5.14" }
    compileOptions { sourceCompatibility = JavaVersion.VERSION_17; targetCompatibility = JavaVersion.VERSION_17 }
    kotlinOptions { jvmTarget = "17" }
}
dependencies {
    implementation(platform("androidx.compose:compose-bom:2024.06.00"))
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.activity:activity-compose:1.9.0")
}

package com.example.ledger

import android.Manifest
import android.os.Bundle
import android.provider.Telephony
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import java.text.NumberFormat
import java.util.Calendar
import java.util.Locale

val CATS = listOf("Food", "Groceries", "Transport", "Bills", "Rent", "Shopping", "Health", "Fun", "Salary", "Other")

class MainActivity : ComponentActivity() {
    private var txs by mutableStateOf(listOf<Tx>())

    override fun onCreate(s: Bundle?) {
        super.onCreate(s)
        val perm = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
            importInbox(); txs = Store.all(this)
        }
        perm.launch(arrayOf(Manifest.permission.RECEIVE_SMS, Manifest.permission.READ_SMS))
        setContent {
            MaterialTheme(colorScheme = if (isSystemInDarkTheme()) darkColorScheme() else lightColorScheme()) {
                Surface(Modifier.fillMaxSize().systemBarsPadding()) {
                    App(txs, { id, c -> Store.setCat(this, id, c); txs = Store.all(this) },
                        { id -> Store.delete(this, id); txs = Store.all(this) })
                }
            }
        }
    }

    override fun onResume() { super.onResume(); txs = Store.all(this) }

    /** Reads this month's existing SMS once permission is granted, so nothing is missed. */
    private fun importInbox() {
        try {
            val start = Calendar.getInstance().apply {
                set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0)
            }.timeInMillis
            val found = mutableListOf<Tx>()
            contentResolver.query(Telephony.Sms.Inbox.CONTENT_URI, arrayOf("body", "date"), "date>=?",
                arrayOf(start.toString()), null)?.use {
                while (it.moveToNext()) Store.parse(it.getString(0) ?: "", it.getLong(1))?.let(found::add)
            }
            Store.addAll(this, found)
        } catch (e: SecurityException) { }
    }
}

fun inr(n: Double): String = "₹" + NumberFormat.getNumberInstance(Locale("en", "IN")).format(Math.round(n))

@Composable
fun App(l: List<Tx>, onCat: (Long, String) -> Unit, onDel: (Long) -> Unit) {
    var tab by remember { mutableStateOf(0) }
    val pending = l.count { it.cat == null }
    Column {
        TabRow(selectedTabIndex = tab) {
            Tab(tab == 0, { tab = 0 }, text = { Text("Dashboard") })
            Tab(tab == 1, { tab = 1 }, text = { Text("Categorize" + if (pending > 0) " ($pending)" else "") })
        }
        if (tab == 0) Dash(l) else Sort(l.filter { it.cat == null }, onCat, onDel)
    }
}

@Composable
fun Dash(l: List<Tx>) {
    val now = Calendar.getInstance()
    val m = l.filter {
        val c = Calendar.getInstance().apply { timeInMillis = it.ts }
        c.get(Calendar.YEAR) == now.get(Calendar.YEAR) && c.get(Calendar.MONTH) == now.get(Calendar.MONTH)
    }
    val out = m.filter { !it.isIn }
    val spent = out.sumOf { it.amt }
    val got = m.filter { it.isIn }.sumOf { it.amt }
    val by = out.groupBy { it.cat ?: "Uncategorized" }.mapValues { e -> e.value.sumOf { it.amt } }.toList().sortedByDescending { it.second }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        item {
            Text("Spent this month", style = MaterialTheme.typography.labelLarge)
            Text(inr(spent), fontSize = 40.sp, color = MaterialTheme.colorScheme.error)
            Text("Received ${inr(got)}  ·  Net ${inr(got - spent)}")
        }
        if (by.isEmpty()) item { Text("No transactions yet this month. Bank SMS appear here automatically.") }
        items(by) { (k, v) ->
            Column {
                Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween) { Text(k); Text(inr(v)) }
                LinearProgressIndicator(progress = { (v / spent).toFloat() }, Modifier.fillMaxWidth().padding(top = 4.dp))
            }
        }
    }
}

@Composable
fun Sort(l: List<Tx>, onCat: (Long, String) -> Unit, onDel: (Long) -> Unit) {
    if (l.isEmpty()) { Text("All caught up. New debits and credits show up here.", Modifier.padding(16.dp)); return }
    LazyColumn(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        items(l.sortedByDescending { it.ts }) { t ->
            Card(Modifier.fillMaxWidth()) {
                Column(Modifier.padding(12.dp)) {
                    Row(Modifier.fillMaxWidth(), Arrangement.SpaceBetween, Alignment.CenterVertically) {
                        Column {
                            Text(t.who, style = MaterialTheme.typography.titleMedium)
                            Text(java.text.DateFormat.getDateTimeInstance(java.text.DateFormat.MEDIUM, java.text.DateFormat.SHORT).format(t.ts),
                                style = MaterialTheme.typography.bodySmall)
                        }
                        Text((if (t.isIn) "+" else "−") + inr(t.amt), style = MaterialTheme.typography.titleMedium,
                            color = if (t.isIn) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.error)
                    }
                    Row(Modifier.horizontalScroll(rememberScrollState()).padding(top = 8.dp), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        CATS.forEach { c -> AssistChip(onClick = { onCat(t.id, c) }, label = { Text(c) }) }
                    }
                    TextButton(onClick = { onDel(t.id) }) { Text("Not a transaction") }
                }
            }
        }
    }
}
